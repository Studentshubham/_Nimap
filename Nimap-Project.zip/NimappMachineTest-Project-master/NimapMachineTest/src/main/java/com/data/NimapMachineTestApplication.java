package com.data;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NimapMachineTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(NimapMachineTestApplication.class, args);
	}

}
